<?php $__env->startSection('popup_add'); ?>



<?php $__env->stopSection(); ?>



<?php echo $__env->make('products.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\PyProj\crud-method\resources\views/products/create.blade.php ENDPATH**/ ?>