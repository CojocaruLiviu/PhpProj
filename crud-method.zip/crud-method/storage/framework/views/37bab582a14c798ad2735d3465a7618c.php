<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Products</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css" integrity="sha512-vKMx8UnXk60zUwyUnUPM3HbQo8QfmNx7+ltw8Pm5zLusl1XIfwcxo8DbWCqMGKaWeNxWA8yrx5v3SaVpMvR3CA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
</head>
<body>
<h1>List with Products</h1>

<div>
    <div class="bd-example">
        <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#AddModal">
            Click to add
        </button>
    </div>
</div>

<!-- Modal page Add -->
<div class="modal fade" id="AddModal" tabindex="-1" aria-labelledby="AddModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h1 class="modal-title fs-5" id="AddModalLabel">Add Product</h1>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <?php if($errors->any()): ?>
                <div>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            <?php endif; ?>
            <form method="post" action="<?php echo e(route('product.store')); ?>">
                <div class="modal-body">
                        <?php echo csrf_field(); ?>
                        <input type="name" name="name" id="name" placeholder="Name" class="form-control"><br>
                        <input type="age" name="age" id="age" placeholder="Count" class="form-control"><br>
                        <textarea name="about" id="about" class="form-control" placeholder="About" cols="30" rows="10"></textarea><br>
                </div>
                <div class="modal-footer">
                    <button type="close" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-primary">Add</button>
                </div>
            </form>
        </div>
    </div>
</div>


<br>
<div class="container">
    <table border="1" class="table ">
        <tr>
            <td>Id</td>
            <td>Name</td>
            <td>Count</td>
            <td>About</td>
            <td>Edit</td>
            <td>Delete</td>
        </tr>

        <?php $__currentLoopData = $product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $el): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($el->id); ?></td>
                <td><?php echo e($el->name); ?></td>
                <td><?php echo e($el->age); ?></td>
                <td><?php echo e($el->about); ?></td>
                <td>
                    <!-- Button to trigger the modal -->
                    <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#EditModal<?php echo e($el->id); ?>">
                        Edit
                    </button>
                </td>
                <td>

                    <button type="submit" class="btn btn-primary" value="delete" data-bs-toggle="modal" data-bs-target="#DelModal<?php echo e($el->id); ?>">
                        Delete
                    </button>
                </td>
            </tr>

            <!-- Edit Modal product -->
            <div class="modal fade" id="EditModal<?php echo e($el->id); ?>" tabindex="-1" aria-labelledby="EditModalLabel<?php echo e($el->id); ?>" aria-hidden="true">
                <div class="modal-dialog">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h1 class="modal-title fs-5" id="EditModalLabel<?php echo e($el->id); ?>">Edit Product</h1>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <form method="post" action="<?php echo e(route('product.update', ['product' => $el->id])); ?>">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('put'); ?>
                            <div class="modal-body">
                                <input type="name" name="name" id="name" placeholder="Name" class="form-control" value="<?php echo e($el->name); ?>"><br>
                                <input type="age" name="age" id="age" placeholder="Count" class="form-control" value="<?php echo e($el->age); ?>"><br>
                                <textarea name="about" id="about" class="form-control" placeholder="About" cols="30" rows="10"><?php echo e($el->about); ?></textarea><br>
                            </div>
                            <div class="modal-footer">
                              <a href="/">  <button type="button" class="btn btn-secondary">Close</button></a>
                                <button type="submit" class="btn btn-primary">Edit</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>

            <!-- Delete Modal product -->
            <div class="modal fade" id="DelModal<?php echo e($el->id); ?>" tabindex="-1" aria-labelledby="DelModalLabel<?php echo e($el->id); ?>" aria-hidden="true">
                <div class="modal-dialog">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h1 class="modal-title fs-5" id="DelModalLabel<?php echo e($el->id); ?>">Delete Product</h1>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <form method="post" action="<?php echo e(route('product.destroy', ['product' => $el->id])); ?>">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('delete'); ?>
                            <div class="modal-body">
                                <h2>Are u sure want to delete element with id <?php echo e($el->id); ?> ?</h2>
                            </div>
                            <div class="modal-footer">
                                <a href="/">  <button type="button" class="btn btn-secondary">Close</button></a>
                                <button type="submit" value="delete" class="btn btn-primary">Delete</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
</div>

<?php if(Session::has('success')): ?>
    <script>
        toastr.success("<?php echo e(Session::get('success')); ?>");
    </script>
<?php endif; ?>

<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js" integrity="sha512-VEd+nq25CkR676O+pLBnDW09R7VQX9Mdiij052gVCp5yVH3jGtH70Ho/UUv4mJDsEdTvqRCFZg0NKGiojGnUCw==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.min.js" integrity="sha384-BBtl+eGJRgqQAUMxJ7pMwbEyER4l1g+O15P+16Ep7Q9Q+zqX6gSbd85u4mG4QzX+" crossorigin="anonymous"></script>
</body>
</html>
<?php /**PATH D:\PyProj\crud-method\resources\views/products/index.blade.php ENDPATH**/ ?>