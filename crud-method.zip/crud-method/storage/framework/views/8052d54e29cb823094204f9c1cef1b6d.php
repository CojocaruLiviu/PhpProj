<?php $__env->startSection('edite'); ?>
    form method="post" action="<?php echo e(route('product.update',['product'=>$product])); ?>">
        <?php echo csrf_field(); ?>
        <?php echo method_field('put'); ?>
        <input type="name" name="name" id="name" placeholder="Introdu nume" value="<?php echo e($product->name); ?>" class="form-control"><br>
        <input type="age" name="age" id="age" placeholder="age" value="<?php echo e($product->age); ?>" class="form-control"><br>
        <input name="about" id="about" class="form-control" placeholder="about" value="<?php echo e($product->about); ?>" cols="30" rows="10"></input><br>
        <button type="submit" class="btn btn-success ">Edit Prod</button>
        <a href="/"> <button type="cancel" class="btn btn-success">Cancel</button></a>
    </form>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('products.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\PyProj\crud-method\resources\views/products/edit.blade.php ENDPATH**/ ?>